---
feature: "streaming-block-decompression"
created: "2026-03-18"
status: "resolved"
---

# Domain Analysis — streaming-block-decompression

## Overview
This feature modifies the SSTable reader's scan iterators to decompress blocks
lazily rather than upfront. It operates within the v2 compressed SSTable format
governed by two existing ADRs, and is informed by research into how different
index types actually use the scan path — which validates the iterator-local
buffer approach over BlockCache integration.

## Domains

### SSTable Block Compression Format
**Status:** resolved
**Relevance:** The v2 file layout and compression map structure determine how the
streaming iterator navigates blocks — specifically the `CompressionMap.Entry`
provides `blockOffset`, `compressedSize`, `uncompressedSize`, and `codecId` needed
for on-demand decompression.

**KB entries:**
- [`.kb/algorithms/compression/block-compression-algorithms.md`](../../.kb/algorithms/compression/block-compression-algorithms.md) — codec characteristics and per-block overhead

**Governing ADR:**
- [`.decisions/sstable-block-compression-format/adr.md`](../../.decisions/sstable-block-compression-format/adr.md) — Compression Offset Map format: flat array of per-block metadata loaded at reader open time

**Guidance for implementation:**
The compression map is already loaded at reader open time and provides random
access to any block's metadata by index. The streaming iterator can use
`compressionMap.entry(blockIndex)` to decompress blocks on demand without any
format changes. The v2 key index stores `(blockIndex, intraBlockOffset)` pairs
which map directly to compression map entries.

---

### Compression Codec API
**Status:** resolved
**Relevance:** The codec interface contract determines how per-block decompression
is invoked from the iterator.

**Governing ADR:**
- [`.decisions/compression-codec-api-design/adr.md`](../../.decisions/compression-codec-api-design/adr.md) — Open interface + explicit codec list; reader takes varargs codecs

**Guidance for implementation:**
The existing `readAndDecompressBlock(int blockIndex)` method already implements
the correct decompression flow: read compressed bytes, look up codec by ID,
decompress. The streaming iterator should reuse this method rather than
reimplementing decompression. The codec map (`Map<Byte, CompressionCodec>`) is
already available on the reader instance.

---

### Index Scan Patterns over LSM Storage
**Status:** resolved
**Relevance:** Research commission from the brief — determines whether the
iterator-local buffer approach is correct or whether scan-path BlockCache
integration is needed.

**KB entries:**
- [`.kb/systems/lsm-index-patterns/index-scan-patterns.md`](../../.kb/systems/lsm-index-patterns/index-scan-patterns.md) — access pattern taxonomy for inverted, vector, and table indices

**Guidance for implementation:**
Research confirms the iterator-local buffer is the correct approach:
- **Inverted index** (LsmInvertedIndex): prefix-bounded range scans — tight,
  sequential, rarely revisits blocks across queries
- **IVF-Flat** (LsmVectorIndex): namespace scans for centroids + per-centroid
  posting list scans — centroid blocks would benefit from caching but that's a
  separate optimization (future work)
- **HNSW** (LsmVectorIndex): point gets only — no scans at all; scan-path
  cache isolation actually *protects* HNSW cache entries from pollution
- **Table range queries**: application-bounded scans — unpredictable reuse

No current index type benefits from caching scan-path blocks across queries.
Iterator-local buffer prevents cache pollution and matches all observed patterns.

---

## Unresolved Gaps
None.

## Key Constraints for Implementation
- Use the existing `readAndDecompressBlock(int blockIndex)` method — do not
  reimplement decompression logic
- The compression map is loaded at reader open time — no additional I/O needed
  to navigate blocks
- Iterator must maintain its own block buffer — do not interact with BlockCache
  during scans (prevents pollution of point-get cache entries)
- v1 code paths must remain completely unchanged
- The v2 key index stores packed `(blockIndex << 32 | intraBlockOffset)` — the
  iterator can extract `blockIndex` to detect block transitions and reuse the
  current decompressed block for consecutive entries in the same block
