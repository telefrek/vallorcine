# Cycle Log — table-partitioning / WU-1
<!-- Append-only. Each agent appends entries. -->
---
