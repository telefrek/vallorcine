---
feature: "table-partitioning"
created: "2026-03-16"
status: "resolved"
---

# Domain Analysis — table-partitioning

## Overview
Table partitioning distributes documents across multiple range-based partitions,
each containing a self-contained JlsmTable with co-located indices. The technical
landscape spans data partitioning strategies, distributed query execution
(scatter-gather), result fusion (top-k merge and RRF), and partition metadata
management. All domains are covered by existing KB research and ADR-001.

## Domains

### Partitioning Strategy
**Status:** resolved
**Relevance:** The foundational design choice — determines how data is distributed and how queries are routed.

**KB entries:**
- [`.kb/distributed-systems/data-partitioning/partitioning-strategies.md`](../../.kb/distributed-systems/data-partitioning/partitioning-strategies.md) — range vs hash vs consistent hashing; range partitioning lifecycle; routing with meta-ranges; edge cases (hotspots, empty ranges, split during compaction)
- [`.kb/distributed-systems/data-partitioning/vector-search-partitioning.md`](../../.kb/distributed-systems/data-partitioning/vector-search-partitioning.md) — per-partition co-located index topology; why HNSW doesn't shard well; IVF as natural distributed index

**Governing ADR:**
- [`.decisions/table-partitioning/adr.md`](../../.decisions/table-partitioning/adr.md) — Range Partitioning with Per-Partition Co-located Indices. Hash and Global IVF rejected.

**Guidance for implementation:**
Use contiguous, non-overlapping key ranges. Each partition owns all documents where `key >= low && key < high`. Route key-based operations via binary search on the range map. Start with a single range covering the full keyspace if only one partition is configured.

---

### Scatter-Gather Query Execution
**Status:** resolved
**Relevance:** Multi-partition queries (vector, full-text, combined) require parallel dispatch to all partitions and result merging.

**KB entries:**
- [`.kb/distributed-systems/data-partitioning/vector-search-partitioning.md`](../../.kb/distributed-systems/data-partitioning/vector-search-partitioning.md) — scatter-gather topology, code skeleton for DistributedVectorQuery, per-partition local search with filter

**Governing ADR:**
- [`.decisions/table-partitioning/adr.md`](../../.decisions/table-partitioning/adr.md) — specifies scatter-gather as the query model for vector/text/combined queries

**Guidance for implementation:**
Dispatch query to all partitions in parallel (in-process: virtual threads or executor). Each partition returns local top-k. Coordinator merges. Design the dispatch interface to accept both in-process and future remote implementations. Use configurable timeout with partial-result support.

---

### Result Fusion
**Status:** resolved
**Relevance:** Merging ranked results from multiple partitions requires different strategies per query type.

**KB entries:**
- [`.kb/distributed-systems/data-partitioning/vector-search-partitioning.md`](../../.kb/distributed-systems/data-partitioning/vector-search-partitioning.md) — top-k merge for vector; RRF for hybrid (vector + BM25); weighted score combination `final = α·vector_score + (1-α)·bm25_score`

**Governing ADR:**
- No separate ADR needed — fusion is an implementation detail of the scatter-gather model.

**Guidance for implementation:**
- **Property queries:** Union results from overlapping partitions (no ranking needed, just correctness).
- **Vector queries:** Priority queue merge of per-partition top-k lists by similarity score.
- **Full-text queries:** Priority queue merge by BM25 score.
- **Hybrid (vector + text):** Per-partition: run both paths, fuse locally with RRF. Coordinator: merge per-partition fused results by final score.
- **Vector + property filter:** Per-partition: apply filter then ANN (pre-filter) or ANN then filter (post-filter). Coordinator: top-k merge of filtered results.

---

### Partition Descriptor Model
**Status:** resolved
**Relevance:** The data model for tracking which partition owns which key range, including metadata for future remote support.

**KB entries:**
- [`.kb/distributed-systems/data-partitioning/partitioning-strategies.md`](../../.kb/distributed-systems/data-partitioning/partitioning-strategies.md) — range map structure (TreeMap of range boundaries), epoch mechanism for staleness detection, TiKV region metadata model

**Governing ADR:**
- [`.decisions/table-partitioning/adr.md`](../../.decisions/table-partitioning/adr.md) — partition descriptors include range boundaries and location metadata (node ID, epoch)

**Guidance for implementation:**
Model as a record: `PartitionDescriptor(id, lowKey, highKey, nodeId, epoch)`. The range map is a sorted structure (TreeMap or similar) mapping low boundaries to descriptors. For the initial in-process implementation, `nodeId` can be a local identifier; the interface should accept any string/URI so remote implementations plug in later.

---

## Unresolved Gaps
None.

## Key Constraints for Implementation
- **ADR-001:** Range partitioning with co-located indices — every partition is a self-contained JlsmTable with all index types
- **Static partitions:** Partition count and boundaries fixed at creation time (dynamic split/merge deferred)
- **In-process only:** All partitions in the same JVM; dispatch interface designed for but not implementing remote
- **Combined query efficiency:** Filtered vector search and hybrid retrieval must execute per-partition without cross-partition joins
- **No data loss:** Key routing must be deterministic; every key maps to exactly one partition
- **Remote-capable interface:** Partition communication abstraction must not assume in-process — use interface/SPI that a network transport can implement later
