# data-partitioning — Category Index
*Topic: distributed-systems*

Strategies for distributing data across multiple nodes in a distributed
storage system. Covers range partitioning, hash partitioning, consistent
hashing, and hybrid approaches, with focus on tradeoffs for LSM-tree
backed stores that need range scan support.

## Contents

| File | Subject | Status | Key Metric | Best For |
|------|---------|--------|------------|----------|
| [partitioning-strategies.md](partitioning-strategies.md) | Range, Hash, Consistent Hashing comparison | active | O(log R) routing | Choosing a partitioning model |

## Research Gaps
- Partition rebalancing algorithms (load-aware vs size-aware splitting)
- Raft/Paxos per-partition replication details
- Multi-tenant partition isolation strategies
- Cross-partition transaction coordination (2PC, Calvin, Percolator)

## Shared References Used
@../../_refs/complexity-notation.md
