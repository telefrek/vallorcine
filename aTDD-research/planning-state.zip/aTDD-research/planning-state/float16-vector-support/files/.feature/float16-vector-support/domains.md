---
feature: "float16-vector-support"
created: "2026-03-12"
status: "resolved"
---

# Domain Analysis — float16-vector-support

## Overview
This feature adds IEEE 754 half-precision (float16) vector storage and querying to the existing
IvfFlat and Hnsw implementations in jlsm-vector. The key technical domains are float16
encoding/conversion, SIMD distance computation strategy, and API design for exposing precision
as a property.

## Domains

### Float16 Encoding/Conversion
**Status:** resolved
**Relevance:** Core mechanism for converting float32 inputs to float16 storage format.

**KB entries:** None — standard Java API coverage is sufficient.

**Governing ADR:** None needed.

**Guidance for implementation:**
Use `Float.floatToFloat16(float)` and `Float.float16ToFloat(short)` from `java.lang.Float`
(available since Java 20). These are intrinsified by the JVM. IEEE 754 binary16 semantics apply:
NaN, Infinity, subnormals, and overflow/underflow follow standard rounding rules. No custom
conversion logic needed.

---

### Float16 SIMD Distance Computation
**Status:** resolved
**Relevance:** How to compute distances efficiently when vectors are stored as float16.

**KB entries:** None — research conducted during domain analysis.

**Governing ADR:** None needed.

**Guidance for implementation:**
Java 25's `jdk.incubator.vector` has no native `Float16Vector`. The approach is: store vectors as
`short[]` (float16 bits), decode to `float[]` via `Float.float16ToFloat()`, then compute distances
using `FloatVector` SIMD (dot product, euclidean, cosine). Precision loss comes from the storage
quantization step (float32 → float16 on write), not from the computation path. This is the same
strategy used by Lucene and similar Java vector search libraries.

Future opportunity: `Float16Vector` is in active OpenJDK development (JDK-8370691), expected
JDK 27+. When available, the inner distance loop can be swapped to native float16 SIMD without
changing the storage format.

---

### VectorIndex Precision API
**Status:** gap-noted
**Relevance:** How to expose the configured precision (float32 vs float16) on the VectorIndex
interface so consumers can discover it.

**KB entries:** None.

**Governing ADR:** None — user deferred to work planner.

**Guidance for implementation:**
Work planner has discretion on API design (enum, method, type parameter, etc.). Must be
discoverable from the VectorIndex instance. User is open to refactoring the approach later if
needed.

---

## Unresolved Gaps
- VectorIndex precision API design — deferred to work planner per user confirmation.

## Key Constraints for Implementation
- Use `Float.floatToFloat16()` / `Float.float16ToFloat()` for all conversions (Java 20+ standard API)
- Store vectors as `short[]` (float16 bits), decode to `float[]` for SIMD distance computation
- IvfFlat centroids remain float32 — only posting-list vectors use float16
- HNSW neighbor links unchanged — only vector payload shrinks
- Float16 and float32 are separate index types, no mixed-precision
- Precision is an explicit builder choice, never auto-selected
