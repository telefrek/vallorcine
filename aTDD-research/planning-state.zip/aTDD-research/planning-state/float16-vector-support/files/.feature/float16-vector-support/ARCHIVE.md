---
feature: "float16-vector-support"
archived: "2026-03-16"
pr_merged: "yes"
---

# Archive Manifest — float16-vector-support

## Feature Summary
Add float16 (half-precision) vector storage and distance computation to both
IvfFlat and Hnsw implementations in jlsm-vector. Vectors accepted as float[]
at the API boundary and quantized to float16 internally. ~50% storage reduction
per vector.

## What Was Built
- VectorPrecision enum (FLOAT32, FLOAT16)
- VectorIndex.precision() property
- encodeFloat16s/decodeFloat16s conversion utilities
- encodeVector/decodeVector precision-dispatched encoding
- IvfFlat float16 storage (centroids remain float32)
- Hnsw float16 node encoding/decoding

## Files Created / Modified
- LsmVectorIndex.java — IvfFlat.search, Hnsw.encodeNode/decodeNode, 4 call sites each
- VectorPrecision.java — new enum
- VectorIndex.java — precision() method added
- LsmVectorIndexFloat16Test.java — 19 tests
- VectorPrecisionTest.java — 2 tests

## TDD Summary
- Cycles completed: 1
- Tests written: 21
- Missing tests found during refactor: 0

## Decisions Made
None — no ADRs created. Float16 encoding uses standard Java API (Float.float16ToFloat /
Float.floatToFloat16). SIMD uses store-as-short-decode-to-float approach pending
Float16Vector in JDK 27+.

## KB Entries Used
None — no KB entries created or consulted.

## Why Archived
PR #8 merged 2026-03-14 — working state no longer needed locally.
Source code and tests are in git history.
