---
feature: "float16-vector-support"
created: "2026-03-13"
status: "draft"
---

# PR Draft — float16-vector-support

## Title
feat(jlsm-vector): add float16 vector storage to IvfFlat and Hnsw

## Description
## What
Adds IEEE 754 half-precision (float16) vector storage to both IvfFlat and Hnsw
implementations in jlsm-vector. Vectors are accepted as `float[]` at the API
boundary and quantized to float16 internally, achieving ~50% storage reduction
per vector. Precision is an explicit builder choice — existing float32 indices
are completely unaffected.

## Changes
- `VectorPrecision` enum in jlsm-core: `FLOAT32(4)`, `FLOAT16(2)` with `bytesPerComponent()`
- `VectorIndex.precision()` method on the sealed interface
- `encodeFloat16s`/`decodeFloat16s` static helpers using `Float.floatToFloat16`/`float16ToFloat`
- `encodeVector`/`decodeVector` precision-dispatch methods
- IvfFlat: posting-list vectors stored at configured precision; centroids remain float32
- Hnsw: node vector portion stored at configured precision; neighbor links unchanged
- `AbstractBuilder.precision()` method with `FLOAT32` default and null validation

## Tests
21 tests across 2 files:
- `VectorPrecisionTest` (2 tests): enum `bytesPerComponent()` values
- `LsmVectorIndexFloat16Test` (19 tests): float16 encode/decode roundtrip,
  special values (NaN/Infinity/zero), encodeVector/decodeVector dispatch,
  IvfFlat and Hnsw float16 index/search/remove integration, score accuracy,
  default precision verification, builder null rejection

## Notes for reviewer
- Distance computation always uses float32 SIMD — float16 is storage-only.
  True float16 SIMD (`Float16Vector`) is expected in JDK 27+ (JDK-8370691).
- Recall delta vs float32 is not measured in this PR (deferred to benchmark).

## Review checklist
- [ ] Tests pass locally (`./gradlew test`)
- [ ] Linter passes (`./gradlew spotlessCheck checkstyleMain checkstyleTest`)
- [ ] Integration tests pass (`./gradlew :tests:jlsm-remote-integration:test`)
- [ ] No unintended side effects on existing float32 vector indices

---
*Generated from brief.md, work-plan.md, and cycle-log.md on 2026-03-13.*
*Copy the Title and Description sections directly into your PR.*
