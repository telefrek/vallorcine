---
feature: "table-indices-and-queries"
archived: "2026-03-16"
pr_merged: "yes"
---

# Archive Manifest — table-indices-and-queries

## Feature Summary
Add secondary index support and a fluent query API to jlsm-table. Indices are
owned by the table and support equality, range, unique-constraint, full-text
(via jlsm-indexing), and vector (via jlsm-vector) types. The query API uses a
fluent builder with predicate combinators (and/or).

## What Was Built
- IndexType enum (EQUALITY, RANGE, UNIQUE, FULL_TEXT, VECTOR)
- IndexDefinition record
- FieldValueCodec (sort-preserving encoding for all primitive types)
- SecondaryIndex sealed interface
- FieldIndex (in-memory TreeMap-backed equality/range/unique index)
- FullTextFieldIndex (stub — delegates to LsmInvertedIndex)
- VectorFieldIndex (stub — delegates to LsmVectorIndex)
- IndexRegistry (validates definitions, routes writes, finds matching index)
- Predicate sealed interface (Eq, Ne, Gt, Gte, Lt, Lte, Between, FullTextMatch, VectorNearest, And, Or)
- TableQuery fluent builder (where/and/or chaining, 9 operators via FieldClause)
- QueryExecutor (index-backed lookup, scan-and-filter fallback, And intersection, Or union)

## Files Created / Modified
- IndexType.java, IndexDefinition.java — new
- FieldValueCodec.java — new
- SecondaryIndex.java, FieldIndex.java, FullTextFieldIndex.java, VectorFieldIndex.java — new
- IndexRegistry.java — new
- Predicate.java — new
- TableQuery.java — new
- QueryExecutor.java — new
- IndexDefinitionTest.java, FieldValueCodecTest.java, FieldIndexTest.java, IndexRegistryTest.java — new (WU-1)
- PredicateTest.java, TableQueryTest.java, QueryExecutorTest.java — new (WU-2)

## TDD Summary
- Cycles completed: 2 (one per work unit)
- Tests written: 65 (29 WU-1 + 36 WU-2)
- Missing tests found during refactor: 0

## Decisions Made
None — no ADRs created. All index types compose existing jlsm modules.

## KB Entries Used
None — no KB entries created or consulted.

## Why Archived
PR #9 merged 2026-03-16 — working state no longer needed locally.
Source code and tests are in git history.
