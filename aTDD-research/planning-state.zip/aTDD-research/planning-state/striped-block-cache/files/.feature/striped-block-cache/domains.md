---
feature: "striped-block-cache"
created: "2026-03-17"
status: "resolved"
---

# Domain Analysis — striped-block-cache

## Overview
The StripedBlockCache partitions the cache key space across N independent LruBlockCache stripes to eliminate single-lock contention. Two design decisions govern the implementation: how keys are mapped to stripes (hash function) and how cross-stripe operations like eviction are performed.

## Domains

### Stripe Hash Function
**Status:** resolved
**Relevance:** Determines distribution quality and per-operation overhead for every get/put call.

**KB entries:**
- None (KB is empty)

**Governing ADR:**
- [`.decisions/stripe-hash-function/adr.md`](../../.decisions/stripe-hash-function/adr.md) — Use Stafford variant 13 (splitmix64 finalizer) for mapping `(sstableId, blockOffset)` to stripe index. Zero-allocation, excellent avalanche for sequential inputs.

**Guidance for implementation:**
Use the splitmix64 finalizer with golden-ratio combining: `sstableId * 0x9E3779B97F4A7C15L + blockOffset`, then three multiply-XOR-shift stages. Constants are from `java.util.SplittableRandom`. Output mapped to stripe index via `% stripeCount` (or `& (stripeCount - 1)` for power-of-2 counts as a future optimization).

---

### Cross-Stripe Eviction
**Status:** resolved
**Relevance:** Determines how `evict(sstableId)` removes all entries for a compacted SSTable across all stripes.

**KB entries:**
- None (KB is empty)

**Governing ADR:**
- [`.decisions/cross-stripe-eviction/adr.md`](../../.decisions/cross-stripe-eviction/adr.md) — Sequential loop: iterate stripes 0..N-1, calling `stripe.evict(sstableId)` on each. One lock held at a time.

**Guidance for implementation:**
Plain `for` loop delegating to each stripe's existing `evict()` method. Do not expose internal lock/unlock on `LruBlockCache`. Momentary inconsistency during the sweep is acceptable. Do not use parallel streams or acquire all locks simultaneously.

---

## Unresolved Gaps
None.

## Key Constraints for Implementation
- Hash function must be zero-allocation, pure arithmetic on two `long` inputs
- Use splitmix64 constants from JDK's `SplittableRandom` — cite source in a comment
- Eviction is a sequential loop — no parallelism, no thread pool
- Each stripe is a full `LruBlockCache` — delegate all operations, do not break encapsulation
- `close()` must use deferred exception pattern across all stripes
- Capacity is divided evenly: `totalCapacity / stripeCount` per stripe
