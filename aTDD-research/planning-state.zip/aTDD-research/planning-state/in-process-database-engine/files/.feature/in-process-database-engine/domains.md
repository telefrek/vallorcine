---
feature: "in-process-database-engine"
created: "2026-03-19"
status: "resolved"
---

# Domain Analysis — in-process-database-engine

## Overview
The in-process database engine operates at the intersection of table lifecycle management and multi-tenant resource control. Two architectural decisions govern the design: how the engine persists its catalog of tables (per-table metadata directories with lazy recovery), and how callers interact with the engine and its tables (interface-based handle pattern with tracked lifecycle and lease eviction). Both decisions are driven by the same core constraints: 100K+ table scale, per-table failure isolation, seconds-to-first-serve startup, and a dual-mode API supporting embedded and future remote access.

## Domains

### Table Catalog Persistence
**Status:** resolved
**Relevance:** Determines how the engine discovers, registers, and recovers tables across restarts. The choice of persistence model directly affects startup latency, failure isolation, and future clustering compatibility.

**KB entries:**
- [`.kb/systems/database-engines/catalog-persistence-patterns.md`](../../.kb/systems/database-engines/catalog-persistence-patterns.md) — four catalog persistence patterns evaluated (manifest log, per-table dirs, pointer swap, superblock)

**Governing ADR:**
- [`.decisions/table-catalog-persistence/adr.md`](../../.decisions/table-catalog-persistence/adr.md) — Per-Table Metadata Directories: each table gets its own subdirectory with metadata file; advisory catalog index for fast enumeration; lazy initialization on first access

**Guidance for implementation:**
The engine root directory contains one subdirectory per table. Each subdirectory holds a metadata file (schema, config, creation timestamp) and the table's data files (WAL, SSTables). An optional catalog index file at the root enables fast table enumeration but is advisory — the directory structure is authoritative and the index is rebuilt from it if corrupted. Tables are lazily initialized on first access; the in-memory catalog holds lightweight handles (~200 bytes) until a table is actually used. Recovery detects and cleans up partially-created tables (directory exists but no valid metadata file).

---

### Engine API Surface Design
**Status:** resolved
**Relevance:** Defines the public contract callers use to interact with the engine. Must support embedded (in-process) and future remote (client proxy) modes through the same interfaces. Must protect the engine from handle leaks by unreliable clients.

**KB entries:**
- None — evaluated from general Java API design patterns

**Governing ADR:**
- [`.decisions/engine-api-surface-design/adr.md`](../../.decisions/engine-api-surface-design/adr.md) — Interface-Based Handle Pattern with Tracked Lifecycle and Lease Eviction: Engine + Table interfaces, source-attributed handle tracking, greedy-source-first eviction under pressure

**Guidance for implementation:**
Two core interfaces: `Engine` (lifecycle + table management) and `Table extends AutoCloseable` (data operations + query pass-through). `Table.query()` returns the existing jlsm-table `QueryBuilder` directly. Every `getTable()` call returns a tracked handle with source identity and allocation site. The engine enforces configurable handle limits (per-source-per-table, per-table total, engine-wide). Under pressure, the greediest source's oldest handles are evicted first. Evicted handles throw a diagnostic exception carrying table name, source ID, handle counts, allocation site, and eviction reason. `engine.close()` force-invalidates all outstanding handles. Future interception (rate limiting, metrics, cluster routing) is added via decorators on either interface.

---

## Unresolved Gaps
None.

## Key Constraints for Implementation
- **New JPMS module `jlsm-engine`** — depends on `jlsm-table` and transitively `jlsm-core`; exports Engine, Table, TableMetadata, EngineMetrics interfaces; implementations are internal
- **Per-table directory layout** — `<root>/<table-name>/` with metadata file + data files; optional `<root>/_catalog/` index
- **Lazy table initialization** — lightweight handles in ConcurrentHashMap; full table init on first access
- **Thread-safe catalog operations** — CAS-style operations in ConcurrentHashMap for create/drop; serialize DDL during initial loading phase
- **Handle lifecycle tracking** — source attribution, configurable limits, greedy-source-first eviction, diagnostic exceptions
- **AutoCloseable throughout** — Engine and Table both closeable; engine shutdown force-closes all handles
- **No external runtime dependencies** — pure library
- **Future-safe for clustering** — Engine.createTable/dropTable are natural consensus interception points; per-table directories are the unit of distribution
