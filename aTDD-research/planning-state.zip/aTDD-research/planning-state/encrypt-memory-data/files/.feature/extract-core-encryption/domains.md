---
feature: "extract-core-encryption"
created: "2026-03-19"
status: "resolved"
---

# Domain Analysis — extract-core-encryption

## Overview
Extracting encryption primitives from jlsm-table to jlsm-core is primarily a mechanical JPMS refactor, but adding pre-encrypted document support introduces a design decision about how the signal flows through the serialization pipeline. The encryption algorithms and their structural properties (fixed ciphertext expansion) are already well-documented from the prior feature.

## Domains

### JPMS Module Extraction
**Status:** resolved
**Relevance:** Determines package naming, module-info.java changes, and test configuration for the moved classes.

**KB entries:** None needed — follows established architecture conventions.

**Governing ADR:** None — mechanical refactor governed by existing CLAUDE.md architecture rules (interfaces and implementations in jlsm-core, internal packages not exported).

**Guidance for implementation:**
- Create new packages in jlsm-core (e.g., `jlsm.encryption` exported, `jlsm.encryption.internal` not exported)
- Update jlsm-table's module-info.java to `requires jlsm.core` for the encryption packages
- Move test files and update --add-exports in jlsm-core's build.gradle
- EncryptionSpec moves to exported package, encryptors to internal package

---

### Pre-encrypted Document Signaling
**Status:** resolved
**Relevance:** Determines how JlsmDocument communicates "already encrypted" to the serializer, affecting API design and serialization flow.

**KB entries:** None needed (design question, not research).

**Governing ADR:**
- [`.decisions/pre-encrypted-document-signaling/adr.md`](../../.decisions/pre-encrypted-document-signaling/adr.md) — Factory method with boolean field: `JlsmDocument.preEncrypted(...)` sets internal boolean, serializer branches on `isPreEncrypted()` to validate instead of encrypt

**Guidance for implementation:**
- Add `boolean preEncrypted` field to JlsmDocument with default `false`
- Add `JlsmDocument.preEncrypted(schema, fields...)` static factory method
- Add `boolean isPreEncrypted()` accessor
- In SchemaSerializer.serialize(): `if (doc.isPreEncrypted())` → validate ciphertext lengths, skip encryption
- Deserialization path unchanged — always decrypts

---

### Ciphertext Structural Validation
**Status:** resolved
**Relevance:** Determines what the serializer checks when processing pre-encrypted documents to catch client-side bugs early.

**KB entries:**
- [`.kb/algorithms/encryption/searchable-encryption-schemes.md`](../../.kb/algorithms/encryption/searchable-encryption-schemes.md) — documents fixed expansion sizes per scheme

**Governing ADR:** None needed — validation rules derive directly from encryptor contracts.

**Guidance for implementation:**
- AES-SIV: ciphertext = plaintext + 16 bytes (IV). Minimum valid length: 16 bytes.
- AES-GCM: ciphertext = plaintext + 28 bytes (12 IV + 16 tag). Minimum valid length: 28 bytes.
- BoldyrevaOPE: encrypted value is a long — no length validation needed (type-safe)
- DCPE-SAP: encrypted vector has same dimensionality — validate dimension count matches schema
- Null/empty bytes on an encrypted field → reject with IllegalArgumentException
- Validation is structural only — does not decrypt to verify content

---

## Unresolved Gaps
None.

## Key Constraints for Implementation
- EncryptionSpec must be in an exported package in jlsm-core (clients need it for schema construction)
- Encryptors in internal (non-exported) package — clients use FieldEncryptionDispatch, not raw encryptors
- Wait — FieldEncryptionDispatch is being exported from jlsm-table. Clients needing core-only encryption would use encryptors directly. So encryptors should also be in an exported package, or FieldEncryptionDispatch needs a core-level equivalent.
- Pre-encrypted flag is per-document, all-or-nothing
- Existing JlsmDocument construction paths must be unaffected (backward compat)
- All existing jlsm-table tests must pass without modification
