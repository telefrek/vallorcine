---
feature: "ope-type-aware-bounds"
created: "2026-03-19"
---

# Cycle Log — ope-type-aware-bounds

## 2026-03-19 — Planning complete

- work-plan.md written covering all switch sites, OPE domain derivation, and documentation

## 2026-03-19 — Tests written (Cycle 1)

- Created BoundedStringOpeTest.java with 27 tests covering:
  - BoundedString construction and factory methods (6 tests)
  - OPE domain derivation for INT8, INT16, INT32, BoundedString(2), BoundedString(6) (7 tests)
  - IndexRegistry validation: unbounded STRING rejected, BoundedString accepted (4 tests)
  - JlsmDocument BoundedString validation: accept/reject strings by length (5 tests)
  - DocumentSerializer round-trip with BoundedString fields (2 tests)
  - JSON and YAML round-trip with BoundedString fields (2 tests)
- Updated CiphertextValidatorTest for new OPE ciphertext format (9 bytes)

## 2026-03-19 — Implementation complete (Cycle 1)

### New constructs:
- `FieldType.BoundedString(int maxLength)` — new sealed permit record
- `FieldType.string(int maxLength)` — static factory returning BoundedString
- `FieldEncryptionDispatch.deriveOpeBounds(FieldType)` — type-aware OPE domain/range
- `FieldEncryptionDispatch.opeEncryptTyped/opeDecryptTyped` — type-aware OPE byte encoding
- `IndexRegistry.validateOrderPreservingFieldType` — rejects OPE on incompatible types
- `modules/jlsm-core/src/main/java/jlsm/encryption/README.md` — encryption package docs

### Modified files (14 switch sites + 2 instanceof sites updated):
- FieldType.java — permits clause + BoundedString record + factory
- JlsmDocument.java — validateType + getString for BoundedString
- DocumentSerializer.java — measureField, encodeField, decodeField (3 switch sites)
- FieldEncryptionDispatch.java — OPE dispatch rewritten with type-aware bounds
- IndexRegistry.java — validate() + validateOrderPreservingFieldType + extractFieldValue
- QueryExecutor.java — extractFieldValue instanceof chain
- FieldValueCodec.java — encode/decode instanceof checks (2 sites)
- JsonParser.java, JsonWriter.java — 1 switch site each
- YamlParser.java, YamlWriter.java — 1 and 2 switch sites respectively
- CiphertextValidator.java — OPE_EXACT_LENGTH updated to 9

### Key design decisions:
- MAX_OPE_BYTES = 2: caps domain at 65536 for practical HG sampling performance
- OPE ciphertext format: [1-byte original-length][8-byte encrypted long] = 9 bytes
- Types wider than 2 bytes (INT32, INT64, TIMESTAMP) use only top 2 bytes for OPE ordering
- Range = domain * 10 ratio for all types

## 2026-03-19 — Refactor complete (Cycle 1)

- spotlessApply run, all formatting clean
- `./gradlew :modules:jlsm-core:check :modules:jlsm-table:check` passes cleanly
- 406 tests pass (including 27 new BoundedStringOpeTest tests)
