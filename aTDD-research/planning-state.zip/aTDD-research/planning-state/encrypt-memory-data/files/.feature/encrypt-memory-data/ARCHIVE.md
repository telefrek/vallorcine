---
feature: "encrypt-memory-data"
archived: "2026-03-19"
---

# Archive Manifest — encrypt-memory-data

## Feature Summary
Opt-in field-level encryption for in-memory data in jlsm-table with type-aware encryption mechanisms (deterministic, order-preserving, distance-preserving, opaque), caller-provided keys, and maximum preserved search functionality including SSE encrypted inverted index.

## What Was Built
- EncryptionSpec sealed interface (5 variants with capability methods)
- EncryptionKeyHolder (Arena-backed off-heap key storage)
- AesSivEncryptor (deterministic, equality-preserving)
- AesGcmEncryptor (opaque, maximum security)
- BoldyrevaOpeEncryptor (order-preserving for range queries)
- DcpeSapEncryptor (distance-preserving for vector ANN)
- FieldEncryptionDispatch (spec-to-encryptor mapping)
- PositionalPostingCodec (T2 phrase/proximity postings)
- SseEncryptedIndex (T3 Curtmola SSE-2 encrypted inverted index)
- FieldDefinition extension (added encryptionSpec component)
- JlsmSchema.Builder extension (3-arg field overload)
- DocumentSerializer extension (encrypt/decrypt in encode/decode)
- IndexRegistry extension (capability matrix validation)

## Files Created / Modified
- New: EncryptionSpec.java, EncryptionKeyHolder.java, AesSivEncryptor.java, AesGcmEncryptor.java, BoldyrevaOpeEncryptor.java, DcpeSapEncryptor.java, FieldEncryptionDispatch.java, PositionalPostingCodec.java, SseEncryptedIndex.java
- Modified: FieldDefinition.java, JlsmSchema.java, DocumentSerializer.java, IndexRegistry.java
- Tests: 13 new test files (146 tests total)

## TDD Summary
- Cycles completed: 4 (one per work unit)
- Tests written: 146
- Missing tests found during refactor: 0

## Decisions Made
- .decisions/field-encryption-api-design/adr.md — Schema Annotation with sealed EncryptionSpec
- .decisions/encrypted-index-strategy/adr.md — Static Capability Matrix with 3-tier full-text search

## KB Entries Used
- .kb/algorithms/encryption/searchable-encryption-schemes.md
- .kb/algorithms/encryption/vector-encryption-approaches.md
- .kb/systems/security/jvm-key-handling-patterns.md
