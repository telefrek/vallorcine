---
feature: "encrypt-memory-data"
created: "2026-03-19"
status: "draft"
---

# PR Draft — encrypt-memory-data

## Title
feat(table): add field-level encryption with searchable encryption support

## Description

## What
Adds opt-in field-level encryption to jlsm-table, protecting sensitive field values against memory inspection (heap dumps, cold boot attacks). Each field can be configured with a type-appropriate encryption mechanism — deterministic (AES-SIV) for equality-searchable fields, order-preserving (Boldyreva OPE) for range queries, distance-preserving (DCPE SAP) for vector similarity search, or opaque (AES-GCM) for maximum security. Includes a full SSE encrypted inverted index for T3 full-text search on encrypted fields.

## Changes

### WU-1: Foundation types
- `EncryptionSpec` sealed interface with 5 variants (None, Deterministic, OrderPreserving, DistancePreserving, Opaque) and capability query methods
- `EncryptionKeyHolder` — Arena-backed off-heap key storage with zeroing on close
- `FieldDefinition` extended to carry `EncryptionSpec` (backward-compatible default to NONE)
- `JlsmSchema.Builder` — added 3-arg `field(name, type, encryptionSpec)` overload

### WU-2: Encryption engines
- `AesGcmEncryptor` — standard AES-256-GCM with random IV (opaque encryption)
- `AesSivEncryptor` — deterministic AES-SIV (RFC 5297) for equality-preserving encryption
- `BoldyrevaOpeEncryptor` — order-preserving encryption via hypergeometric sampling
- `DcpeSapEncryptor` — distance-comparison-preserving Scale-And-Perturb for vectors

### WU-3: Serializer + index integration
- `FieldEncryptionDispatch` — maps EncryptionSpec to the correct encryptor per field, with key-size adaptation
- `DocumentSerializer` — encrypt/decrypt integrated into encode/decode paths (length-prefixed blob format)
- `IndexRegistry` — capability matrix validation rejects incompatible encryption × index combinations at construction

### WU-4: Full-text search tiers
- `PositionalPostingCodec` — T2 position-aware postings with OPE-encrypted positions for phrase/proximity queries
- `SseEncryptedIndex` — T3 Curtmola SSE-2 encrypted inverted index with HMAC-SHA256 PRF, forward privacy via state counters

## Tests
146 new tests across 13 test classes covering all encryption engines (round-trip, error cases, security properties), dispatch mapping, encrypted serialization round-trips, index compatibility validation, SSE forward privacy, and concurrent safety. All 426 jlsm-table tests pass.

## Decisions
- **Field Encryption API Design** ([ADR](.decisions/field-encryption-api-design/adr.md)): Schema Annotation pattern — `FieldDefinition` carries sealed `EncryptionSpec`, keys in Arena-backed `EncryptionKeyHolder`
- **Encrypted Index Strategy** ([ADR](.decisions/encrypted-index-strategy/adr.md)): Static Capability Matrix with 3-tier full-text search (T1 DET keyword, T2 DET+OPE phrase, T3 SSE encrypted index)

## Notes for reviewer
- All encryption is pure Java (javax.crypto) — no external dependencies added
- Security tradeoffs are inherent to the schemes: DET leaks frequency, OPE leaks approximate value, DCPE degrades recall — these are documented in the KB entries
- Key material is held off-heap in Arena-backed segments, zeroed on close, never appears in toString/logs
- Acceptance criterion 7 (performance benchmarks) is deferred — the encryption primitives are standard JCE and the overhead is well-understood

## Review checklist
- [ ] Tests pass locally (`./gradlew :modules:jlsm-table:test`)
- [ ] Linter passes (`./gradlew spotlessCheck checkstyleMain checkstyleTest`)
- [ ] Security: key material never leaks to logs, toString, or error messages
- [ ] Security: wrong-key decryption detected (not silent corruption)
- [ ] No unintended side effects on existing unencrypted table paths

---
*Generated from brief.md, work-plan.md, and cycle-log.md on 2026-03-19.*
*Copy the Title and Description sections directly into your PR.*
