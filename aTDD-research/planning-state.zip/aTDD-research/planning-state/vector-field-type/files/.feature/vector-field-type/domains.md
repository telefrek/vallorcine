---
feature: "vector-field-type"
created: "2026-03-17"
status: "resolved"
---

# Domain Analysis — vector-field-type

## Overview
This feature adds a `VectorType` to the sealed `FieldType` hierarchy and tightens the
integration between schema types and vector indices. It touches two architectural domains:
the binary encoding format for vector data in `DocumentSerializer`, and the public API surface
of `IndexDefinition` where vector dimensions were previously specified redundantly.

## Domains

### VectorType Serialization Encoding
**Status:** resolved
**Relevance:** Determines how VectorType fields are serialized/deserialized in DocumentSerializer.

**KB entries:**
- [`.kb/algorithms/vector-encoding/flat-vector-encoding.md`](../../.kb/algorithms/vector-encoding/flat-vector-encoding.md) — chosen encoding format
- [`.kb/algorithms/vector-encoding/sparse-vector-encoding.md`](../../.kb/algorithms/vector-encoding/sparse-vector-encoding.md) — rejected (variable size)
- [`.kb/algorithms/vector-encoding/lossless-vector-compression.md`](../../.kb/algorithms/vector-encoding/lossless-vector-compression.md) — rejected (decode overhead)

**Governing ADR:**
- [`.decisions/vector-type-serialization-encoding/adr.md`](../../.decisions/vector-type-serialization-encoding/adr.md) — Flat contiguous encoding: `d × sizeof(T)` bytes, no per-vector metadata, no length prefix

**Guidance for implementation:**
Use flat contiguous encoding. No VarInt length prefix — dimensions are known from the schema's
`VectorType`. Reuse existing SIMD byte-swap paths for FLOAT32; scalar 2-byte writes for FLOAT16.
Store raw IEEE 754 bits (big-endian), not sort-preserving encoded values.

---

### IndexDefinition API Simplification
**Status:** resolved
**Relevance:** Determines whether `vectorDimensions` stays on `IndexDefinition` or is derived from the schema.

**KB entries:**
- (none — API design decision grounded in codebase)

**Governing ADR:**
- [`.decisions/index-definition-api-simplification/adr.md`](../../.decisions/index-definition-api-simplification/adr.md) — Remove `vectorDimensions` from `IndexDefinition`; derive from schema's `VectorType.dimensions()` at `IndexRegistry` validation time

**Guidance for implementation:**
Remove `vectorDimensions` from the `IndexDefinition` record. Add a three-arg constructor
`IndexDefinition(fieldName, indexType, similarityFunction)` for VECTOR indices. In
`IndexRegistry.validate()`, extract dimensions from `VectorType.dimensions()` and pass to
`VectorFieldIndex`. Update all existing test callsites.

---

## Unresolved Gaps
None.

## Key Constraints for Implementation
- **Flat encoding, no length prefix**: VectorType serialization writes `dimensions × elementWidth`
  bytes contiguously. No VarInt count. Dimensions come from schema.
- **SIMD reuse**: FLOAT32 vectors use the existing `encodeFloat32Array()` / `decodeFloat32Array()`
  SIMD paths (minus the VarInt prefix). FLOAT16 uses scalar 2-byte big-endian writes.
- **Schema is authority**: `VectorType.dimensions()` is the single source of truth for vector
  size. `IndexDefinition` does not carry dimensions. `IndexRegistry` extracts them.
- **Validation at construction**: `VectorType` rejects non-float element types and non-positive
  dimensions at record construction time. `IndexRegistry` rejects VECTOR indices on non-VectorType fields.
- **No null elements**: Individual vector elements are never null. The vector as a whole may be
  null (document-level null bitmask).
