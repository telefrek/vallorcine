## 2026-03-17 — created

**Agent:** Architect Agent
**Event:** created
**Summary:** Constraint profile captured for IndexDefinition API simplification. Pure API design decision — no KB sources needed.

**Files written/updated:**
- `constraints.md` — initial constraint profile

**KB files read:**
- (none — API design decision grounded in codebase, not research)

---
