# algorithms — Topic Index

Algorithm designs, complexity analysis, pseudocode, and encoding schemes
relevant to the jlsm library.

## Categories

| Category | Path | Files | Last Updated |
|----------|------|-------|--------------|
| vector-encoding | [vector-encoding/](vector-encoding/) | 0 | 2026-03-17 |
