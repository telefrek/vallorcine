---
feature: "block-compression"
created: "2026-03-18"
status: "draft"
---

# PR Draft — block-compression

## Title
feat(sstable): add block-level compression to SSTable storage (#17)

## Description

## What
Adds configurable block-level compression to SSTable data blocks. Each block is
independently compressed using a pluggable `CompressionCodec` interface, with
Deflate (via `java.util.zip`) as the built-in codec and a no-op passthrough as
the default. The SSTable format is versioned (v1 → v2) with full backward
compatibility — v2 readers transparently handle v1 files.

## Changes

### WU-1: Compression Codec Types
- New `CompressionCodec` interface in `jlsm.core.compression` with `codecId()`,
  `compress()`, `decompress()`, and static factories `none()`, `deflate()`,
  `deflate(int)`
- `NoneCodec` — passthrough codec (id `0x00`)
- `DeflateCodec` — wraps `Deflater`/`Inflater` with per-call lifecycle (id `0x02`)
- `module-info.java` exports `jlsm.core.compression`

### WU-2: SSTable v2 Format with Compression
- `CompressionMap` — per-block metadata (offset, compressed/uncompressed size,
  codec id) with binary serialization
- `SSTableFormat` — v2 constants: `MAGIC_V2`, `FOOTER_SIZE_V2`,
  `COMPRESSION_MAP_ENTRY_SIZE`
- `TrieSSTableWriter` — accepts `CompressionCodec`, compresses data blocks,
  writes compression map section, emits v2 footer; falls back to `NoneCodec`
  when compression doesn't reduce size
- `TrieSSTableReader` — accepts `CompressionCodec...` varargs, detects v1/v2 by
  magic, reads compression map, decompresses blocks on read; v1 fallback
  preserves existing behaviour
- Key index v2 uses `(blockIndex, intraBlockOffset)` instead of absolute offset

## Tests
39 new tests across 3 test classes:
- `CompressionCodecTest` (19 tests) — round-trip for NoneCodec and DeflateCodec,
  all compression levels 0–9, empty/large inputs, invalid argument handling,
  factory method correctness
- `CompressionMapTest` (9 tests) — serialization round-trip, empty/single/many
  entries, malformed data rejection
- `SSTableCompressionTest` (11 tests) — v2 write/read with NoneCodec and
  DeflateCodec, v1 backward compatibility, incompressible block fallback,
  unknown codec detection, full round-trip verification

## Decisions
- **Codec API:** Open (non-sealed) interface with explicit codec list at reader
  open time — [ADR](/.decisions/compression-codec-api-design/adr.md)
- **On-disk format:** Compression offset map in a separate file section (17
  bytes/block), footer grows to 64 bytes, magic version bump —
  [ADR](/.decisions/sstable-block-compression-format/adr.md)

## Review checklist
- [ ] Tests pass locally (`./gradlew :modules:jlsm-core:check`)
- [ ] No unintended side effects on existing SSTable read/write paths (v1 compat)
- [ ] Compression map serialization matches ADR spec (17 bytes/entry, big-endian)
- [ ] `DeflateCodec` properly releases native `Deflater`/`Inflater` resources

---
*Generated from brief.md, work-plan.md, and cycle-log.md on 2026-03-18.*
*Copy the Title and Description sections directly into your PR.*
