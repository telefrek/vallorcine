---
feature: "block-compression"
archived: "2026-03-18"
pr_merged: "yes"
---

# Archive Manifest — block-compression

## Feature Summary
Add block-level compression to SSTable data blocks in `jlsm-core`. Compression is configurable per-tree via the builder API, allowing different trees to use different codecs or parameters. The SSTable format encodes compression metadata per-block so compressed and uncompressed SSTables are fully interoperable.

## What Was Built
- `CompressionCodec` interface with `codecId()`, `compress()`, `decompress()` and static factories
- `NoneCodec` — passthrough codec (id `0x00`)
- `DeflateCodec` — wraps `Deflater`/`Inflater` with per-call lifecycle (id `0x02`)
- `CompressionMap` — per-block metadata (offset, compressed/uncompressed size, codec id) with binary serialization
- SSTable v2 format: `MAGIC_V2`, `FOOTER_SIZE_V2` (64 bytes), compression map section
- `TrieSSTableWriter` — compresses data blocks, writes compression map, emits v2 footer
- `TrieSSTableReader` — detects v1/v2 by magic, decompresses blocks on read, v1 fallback
- `StandardLsmTree.Builder` — `.compression(CompressionCodec)` method
- `module-info.java` — exports `jlsm.core.compression`

## Files Created / Modified
- `modules/jlsm-core/src/main/java/jlsm/core/compression/CompressionCodec.java` (new)
- `modules/jlsm-core/src/main/java/jlsm/core/compression/NoneCodec.java` (new)
- `modules/jlsm-core/src/main/java/jlsm/core/compression/DeflateCodec.java` (new)
- `modules/jlsm-core/src/main/java/jlsm/sstable/internal/CompressionMap.java` (new)
- `modules/jlsm-core/src/main/java/jlsm/sstable/internal/SSTableFormat.java` (modified)
- `modules/jlsm-core/src/main/java/jlsm/sstable/TrieSSTableWriter.java` (modified)
- `modules/jlsm-core/src/main/java/jlsm/sstable/TrieSSTableReader.java` (modified)
- `modules/jlsm-core/src/main/java/module-info.java` (modified)
- `modules/jlsm-core/src/test/java/jlsm/core/compression/CompressionCodecTest.java` (new)
- `modules/jlsm-core/src/test/java/jlsm/sstable/internal/CompressionMapTest.java` (new)
- `modules/jlsm-core/src/test/java/jlsm/sstable/SSTableCompressionTest.java` (new)

## TDD Summary
- Cycles completed: 1
- Tests written: 39
- Missing tests found during refactor: 0

## Decisions Made
- [compression-codec-api-design](../../.decisions/compression-codec-api-design/adr.md) — Open interface + explicit codec list
- [sstable-block-compression-format](../../.decisions/sstable-block-compression-format/adr.md) — Compression offset map in separate file section

## KB Entries Used
- [block-compression-algorithms](../../.kb/algorithms/compression/block-compression-algorithms.md) — LZ4, Deflate, Snappy, ZSTD comparison

## Why Archived
PR #17 merged 2026-03-18 — working state no longer needed locally.
Source code and tests are in git history.
ADRs and KB entries are permanent and remain in place.
