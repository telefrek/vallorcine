---
feature: "block-compression"
created: "2026-03-17"
status: "resolved"
---

# Domain Analysis — block-compression

## Overview
Block-level compression for SSTable data blocks touches three technical domains: the
compression algorithms themselves, the on-disk format for encoding per-block compression
metadata, and the API design for pluggable codecs. All three are now covered by KB research
and confirmed ADRs.

## Domains

### Block Compression Algorithms
**Status:** resolved
**Relevance:** Determines which compression codecs are viable without external dependencies.

**KB entries:**
- [`.kb/algorithms/compression/block-compression-algorithms.md`](../../.kb/algorithms/compression/block-compression-algorithms.md) — LZ4, Deflate, Snappy, ZSTD comparison; pure-Java feasibility analysis

**Governing ADR:** None (informational domain — no design choice needed)

**Guidance for implementation:**
- Start with Deflate via `java.util.zip.Deflater`/`Inflater` — zero implementation effort, good ratio.
- LZ4 is implementable in ~200 lines of pure Java as a future codec.
- Snappy is strictly dominated by LZ4 — skip it. ZSTD is too complex to hand-roll.
- Always check if compressed output ≥ input — store as NONE if no savings.

---

### SSTable Block Format Changes
**Status:** resolved
**Relevance:** Defines how per-block compression metadata is encoded on disk.

**KB entries:**
- [`.kb/algorithms/compression/block-compression-algorithms.md`](../../.kb/algorithms/compression/block-compression-algorithms.md) — per-block overhead analysis

**Governing ADR:**
- [`.decisions/sstable-block-compression-format/adr.md`](../../.decisions/sstable-block-compression-format/adr.md) — Compression Offset Map: separate file section with per-block metadata array (17 bytes/block), footer grows from 48→64 bytes, key index uses blockIndex + intraBlockOffset

**Guidance for implementation:**
- Data blocks on disk contain compressed payloads only — no inline per-block headers.
- Compression map section: `[blockCount(4)][entries: blockOffset(8) + compressedSz(4) + uncompressSz(4) + codecId(1)]`
- Footer v2: 64 bytes with mapOffset/mapLength prepended, magic `JLSMSST\x02`
- Key index v2: entries use `blockIndex(4) + intraBlockOffset(4)` instead of absolute file offset
- v2 readers must detect v1 files by magic byte and fall back to current logic

---

### Compression Codec API Design
**Status:** resolved
**Relevance:** Defines the interface shape, codec registration, and tree builder integration.

**KB entries:**
- [`.kb/algorithms/compression/block-compression-algorithms.md`](../../.kb/algorithms/compression/block-compression-algorithms.md) — code skeleton for codec interface

**Governing ADR:**
- [`.decisions/compression-codec-api-design/adr.md`](../../.decisions/compression-codec-api-design/adr.md) — Open (non-sealed) `CompressionCodec` interface with `codecId()`, `compress()`, `decompress()`; static factory methods `none()`, `deflate()`, `deflate(int)`; reader takes `CompressionCodec... codecs` varargs; builder adds `.compression(CompressionCodec)`

**Guidance for implementation:**
- `CompressionCodec` interface in `jlsm.core.sstable` (or `jlsm.core.compression` if warranted)
- `NoneCodec`: passthrough, `codecId=0x00`
- `DeflateCodec`: wraps `Deflater`/`Inflater`, `codecId=0x02`, must `end()` native resources
- Writer: if compressed ≥ uncompressed, store block as NONE in the compression map
- Reader: builds `Map<Byte, CompressionCodec>` from varargs at open time; throws on unknown ID
- Tree builder: `.compression(CompressionCodec)` defaults to `CompressionCodec.none()`

---

## Unresolved Gaps
None.

## Key Constraints for Implementation
- No external runtime dependencies — Deflate via `java.util.zip`, LZ4 deferred to future feature
- SSTable format v2 is a breaking change to the on-disk format — magic number version bump required
- v2 readers must handle v1 files transparently (backward compatibility)
- Key index format changes from absolute file offset to (blockIndex, intraBlockOffset)
- Compression map loaded eagerly at reader open time — enables multi-block prefetch for remote backends
- Block cache stores decompressed data — compression/decompression is below the cache layer
- Performance > complexity — format and API complexity are acceptable for better I/O patterns
