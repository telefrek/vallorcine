---
feature: "sql-query-support"
archived: "2026-03-17"
pr_merged: "yes"
---

# Archive Manifest — sql-query-support

## Feature Summary
SQL SELECT parser and translator for `jlsm-table`. Users can query using
familiar SQL syntax instead of the fluent `TableQuery` API. Read-only subset:
SELECT, WHERE (with comparisons, BETWEEN, AND/OR, MATCH, VECTOR_DISTANCE),
ORDER BY, LIMIT/OFFSET. New module `jlsm-sql`.

## What Was Built
- TokenType — enum of all SQL token types
- Token — record (type, text, position)
- SqlParseException — checked exception with position info
- SqlLexer — SQL string → List<Token>
- SqlAst — sealed AST hierarchy (SelectStatement, Column, Expression, OrderByClause)
- SqlParser — recursive descent parser (List<Token> → AST)
- SqlQuery — translated result record (predicate, projections, aliases, orderBy, limit, offset, vectorDistance)
- SqlTranslator — AST + JlsmSchema → SqlQuery (with schema validation)
- JlsmSql — public entry point composing lexer → parser → translator

## Files Created / Modified
- modules/jlsm-sql/build.gradle
- modules/jlsm-sql/src/main/java/module-info.java
- modules/jlsm-sql/src/main/java/jlsm/sql/TokenType.java
- modules/jlsm-sql/src/main/java/jlsm/sql/Token.java
- modules/jlsm-sql/src/main/java/jlsm/sql/SqlParseException.java
- modules/jlsm-sql/src/main/java/jlsm/sql/SqlLexer.java
- modules/jlsm-sql/src/main/java/jlsm/sql/SqlAst.java
- modules/jlsm-sql/src/main/java/jlsm/sql/SqlParser.java
- modules/jlsm-sql/src/main/java/jlsm/sql/SqlQuery.java
- modules/jlsm-sql/src/main/java/jlsm/sql/SqlTranslator.java
- modules/jlsm-sql/src/main/java/jlsm/sql/JlsmSql.java
- modules/jlsm-sql/src/test/java/jlsm/sql/TokenTest.java
- modules/jlsm-sql/src/test/java/jlsm/sql/SqlLexerTest.java
- modules/jlsm-sql/src/test/java/jlsm/sql/SqlParserTest.java
- modules/jlsm-sql/src/test/java/jlsm/sql/SqlTranslatorTest.java
- modules/jlsm-sql/src/test/java/jlsm/sql/JlsmSqlTest.java

## TDD Summary
- Cycles completed: 2 (one per work unit)
- Tests written: 74
- Missing tests found during refactor: 0

## Decisions Made
- Vector similarity SQL syntax: VECTOR_DISTANCE(col, vec, metric) function-based pattern
  (KB: .kb/algorithms/sql-extensions/vector-similarity-sql-syntax.md)

## KB Entries Used
- .kb/algorithms/sql-extensions/vector-similarity-sql-syntax.md

## Why Archived
PR merged — working state no longer needed locally.
Source code and tests are in git history.
ADRs and KB entries are permanent and remain in place.
