---
feature: "sql-query-support"
created: "2026-03-16"
status: "resolved"
---

# Domain Analysis — sql-query-support

## Overview
This feature adds a SQL parsing and translation layer (`jlsm-sql` module) that
converts a supported SQL SELECT subset into the existing `TableQuery` fluent API
and `Predicate` tree. The two technical domains are SQL parsing strategy and
vector similarity search syntax — both are now resolved.

## Domains

### SQL Parsing Strategy
**Status:** resolved
**Relevance:** Determines the parsing architecture for the SQL string → AST pipeline.

**KB entries:**
- No KB entry needed — recursive descent parsing is a well-understood technique.

**Governing ADR:**
- None required — the brief specifies recursive descent, which is the standard
  approach for hand-written parsers of bounded SQL subsets.

**Guidance for implementation:**
Use a hand-written recursive descent parser (no parser generators). The grammar
is small enough (SELECT/FROM/WHERE/ORDER BY/LIMIT/OFFSET with expressions) that
a single-pass parser with a separate lexer is appropriate. The AST should be an
intermediate representation that preserves SQL semantics before translation to
the fluent API.

---

### Vector Similarity SQL Syntax
**Status:** resolved
**Relevance:** Determines what SQL syntax users write for nearest-neighbor vector
queries — an open question in the brief.

**KB entries:**
- [`.kb/algorithms/sql-extensions/vector-similarity-sql-syntax.md`](../../.kb/algorithms/sql-extensions/vector-similarity-sql-syntax.md) — survey of 6 database systems' vector search SQL syntax; recommends function-based Pattern 2 (Oracle-style)

**Governing ADR:**
- None required — the KB research provides a clear recommendation with
  documented rationale.

**Guidance for implementation:**
Use `VECTOR_DISTANCE(column, vector_expr, metric_string)` as a built-in
function recognized by the parser. The function returns a numeric distance score
and is used in ORDER BY with LIMIT for top-K queries:
```sql
SELECT * FROM docs
ORDER BY VECTOR_DISTANCE(embedding, ?, 'cosine')
LIMIT 10;
```
This maps to the existing `TableQuery` ORDER BY + LIMIT mechanics. The metric
parameter is a string literal ('cosine', 'euclidean', 'dot'). The vector value
uses a bind parameter `?` consistent with other parameters in the brief.

---

## Unresolved Gaps
None.

## Key Constraints for Implementation
- **New module `jlsm-sql`**: depends on `jlsm.table` and transitively on `jlsm.core`; must declare JPMS `module-info.java`
- **Read-only**: only SELECT queries are supported; the parser must reject INSERT/UPDATE/DELETE/DDL with a clear error
- **Recursive descent parser**: no parser generator dependencies; hand-written lexer + parser
- **Vector search syntax**: `VECTOR_DISTANCE(col, vec, metric)` in ORDER BY + LIMIT — not a WHERE predicate
- **Bind parameters**: positional `?` placeholders for all value types including vectors
- **Full-text search**: `MATCH(field, 'query')` syntax as specified in the brief, maps to `Predicate.FullTextMatch`
- **AST as intermediate representation**: SQL string → Lexer → Parser → AST → Translator → TableQuery; the AST enables validation and error reporting before translation
- **No external dependencies**: pure Java, consistent with the rest of the library
