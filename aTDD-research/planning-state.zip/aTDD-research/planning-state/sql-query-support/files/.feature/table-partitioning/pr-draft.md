---
feature: "table-partitioning"
created: "2026-03-17"
status: "draft"
---

# PR Draft — table-partitioning

## Title
feat(jlsm-table): add range-based table partitioning

## Description

## What
Adds range-based table partitioning to `jlsm-table`, allowing documents to be
distributed across multiple partitions with co-located indices. A new
`PartitionedTable` coordinator routes key-based CRUD via O(log P) binary search
and executes scatter-gather for vector, full-text, and hybrid queries across
partitions, merging results with top-k priority queue merge.

## Changes

### WU-1: Data model + routing
- `PartitionDescriptor` — record with range bounds, node ID, and epoch
- `ScoredEntry` — record for ranked query results (document + score)
- `PartitionConfig` — validated partition layout with contiguity checks
- `PartitionClient` — SPI interface for dispatching operations (remote-capable)
- `RangeMap` — O(log P) key routing and range overlap queries (internal)

### WU-2: Partition execution
- `InProcessPartitionClient` — wraps `JlsmTable.StringKeyed` for in-process dispatch
- `ResultMerger` — top-k merge via PriorityQueue and N-way ordered merge via MergingIterator (internal)

### WU-3: Coordinator
- `PartitionedTable` — builder-based coordinator with CRUD routing, scatter-gather range queries, and deferred-close pattern

## Tests
85 tests across 7 test classes covering:
- Partition descriptor validation and edge cases
- Scored entry ordering and equality
- Partition config contiguity and overlap rejection
- Range map key routing and overlap queries
- In-process partition client CRUD delegation
- Result merger top-k and ordered merge correctness
- PartitionedTable end-to-end: builder validation, CRUD routing, multi-partition range merge, close accumulation

## Decisions
- **ADR-001:** Range Partitioning with Per-Partition Co-located Indices
  (`.decisions/table-partitioning/adr.md`) — hash partitioning and global IVF
  rejected in favour of range partitioning with co-located indices per partition.

## Review checklist
- [ ] Tests pass locally (`./gradlew :modules:jlsm-table:test`)
- [ ] Full check passes (`./gradlew check`)
- [ ] No unintended side effects on existing `JlsmTable` or `jlsm-sql` modules

---
*Generated from brief.md, work-plan.md, and cycle-log.md on 2026-03-17.*
*Copy the Title and Description sections directly into your PR.*
